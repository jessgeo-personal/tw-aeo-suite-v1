# AEO Suite Frontend v2.0

React frontend for the Answer Engine Optimization (AEO) Audit Suite.

## Features

✅ **OTP-based Authentication** - Secure email verification
✅ **Real-time Analysis** - 5 comprehensive analyzers
✅ **Beautiful Dark Theme** - Professional Thatworkx branding
✅ **Usage Tracking** - Daily limit visualization
✅ **Responsive Design** - Mobile and desktop
✅ **Weighted Scoring** - Intelligent overall grade calculation
✅ **Actionable Recommendations** - Prioritized optimization tips

## Tech Stack

- **React 18** - UI framework
- **React Router DOM** - Client-side routing
- **Tailwind CSS** - Utility-first styling
- **Lucide React** - Beautiful icons
- **Recharts** - Data visualization
- **Axios** - HTTP client

## Installation

```bash
cd aeo-frontend-v2
npm install
```

## Configuration

Create `.env` file:

```bash
cp .env.example .env
```

Update values:
```env
REACT_APP_API_URL=http://localhost:3001
PORT=3000
```

## Development

```bash
npm start
```

Runs on `http://localhost:3000`

## Build for Production

```bash
npm run build
```

Creates optimized build in `/build` directory.

## Project Structure

```
src/
├── components/
│   ├── AuthModal.jsx          # OTP authentication
│   ├── AnalyzerCard.jsx        # Individual analyzer display
│   └── UsageBadge.jsx          # Usage limit indicator
├── pages/
│   ├── LandingPage.jsx         # Entry page with URL input
│   └── Dashboard.jsx           # Results display
├── services/
│   └── api.js                  # Backend API integration
├── utils/
│   └── helpers.js              # Utility functions
├── App.js                      # Main app with routing
├── index.js                    # Entry point
└── index.css                   # Global styles
```

## Components

### AuthModal
Modal for OTP-based email verification with two steps:
1. Email capture (with optional name, country, phone)
2. OTP verification (6-digit code, 10-minute expiry)

### AnalyzerCard
Displays individual analyzer results:
- Score and grade
- Expandable details
- Score breakdown
- Key findings
- Top recommendations

### UsageBadge
Shows daily usage limits:
- Current usage count
- Daily limit
- Color-coded by usage percentage
- Updates in real-time

### LandingPage
Entry page features:
- URL input with validation
- Optional keyword input
- Feature showcase
- User authentication
- Usage tracking

### Dashboard
Results display:
- Overall score with visual grade scale
- 5 expandable analyzer cards
- Prioritized recommendations
- Export functionality
- New analysis button

## Styling

### Color Palette
```javascript
primary:  #0ea5e9  // Sky blue
dark-950: #020617  // Background
dark-900: #0f172a  // Cards
dark-800: #1e293b  // Elements
dark-700: #334155  // Borders
```

### Tailwind Extensions
- Custom dark theme colors
- Glow shadows for primary elements
- Custom animations (pulse-slow, spin-slow)
- Custom scrollbar styling

## API Integration

### Endpoints Used

**Authentication:**
- `POST /api/auth/request-otp` - Send OTP
- `POST /api/auth/verify-otp` - Verify OTP
- `GET /api/auth/session` - Check session
- `POST /api/auth/logout` - Logout

**Analysis:**
- `POST /api/analyze` - Run analysis
- `GET /api/analyses` - Get history

### Request Example

```javascript
const result = await apiService.analysis.runAnalysis(
  'https://example.com',
  ['keyword1', 'keyword2'],
  'user@email.com'
);
```

### Response Structure

```javascript
{
  success: true,
  results: {
    url: "https://example.com",
    overallScore: 75,
    overallGrade: "C",
    analyzers: {
      technicalFoundation: { score, grade, findings, recommendations },
      contentStructure: { score, grade, findings, recommendations },
      pageLevelEEAT: { score, grade, findings, recommendations },
      queryMatch: { score, grade, findings, recommendations },
      aiVisibility: { score, grade, findings, recommendations }
    },
    recommendations: [...],
    processingTime: 3452
  },
  usage: {
    current: 3,
    limit: 10,
    remaining: 7
  }
}
```

## User Flow

1. **Landing Page** → User enters URL (and optional keywords)
2. **Auth Check** → If not authenticated, show AuthModal
3. **OTP Flow** → 
   - User enters email/details
   - OTP sent to email
   - User enters 6-digit code
   - Session created
4. **Analysis** → 
   - Backend runs 5 analyzers
   - Results returned in ~5 seconds
   - Navigate to Dashboard
5. **Dashboard** → 
   - Display overall score
   - Show all 5 analyzer results
   - List recommendations
   - Export or analyze new URL

## Usage Limits

- **Anonymous**: Not allowed (must verify email)
- **Verified Email**: 10 analyses per day
- **Subscribers**: Unlimited

Limits reset at midnight Dubai time (UTC+4).

## Error Handling

- **Network errors**: Graceful fallback messages
- **API errors**: Display error.message to user
- **Session expiry**: Redirect to authentication
- **Rate limiting**: Show upgrade prompt

## Responsive Design

- **Mobile**: Stacked layout, touch-optimized
- **Tablet**: Adapted grid, readable cards
- **Desktop**: Full-width, multi-column layout

Breakpoints:
- `sm`: 640px
- `md`: 768px
- `lg`: 1024px
- `xl`: 1280px

## Browser Support

- Chrome (latest 2 versions)
- Firefox (latest 2 versions)
- Safari (latest 2 versions)
- Edge (latest 2 versions)

## Performance

- **First Load**: ~2-3 seconds
- **Analysis Request**: ~3-5 seconds
- **Page Transitions**: <100ms
- **Bundle Size**: ~500KB (gzipped)

## Deployment

### DigitalOcean App Platform

1. Connect GitHub repository
2. Set build command: `npm run build`
3. Set output directory: `build`
4. Add environment variables
5. Deploy

### Environment Variables (Production)
```env
REACT_APP_API_URL=https://your-backend-url.com
```

## Known Issues

None at this time.

## Future Enhancements

- [ ] Analysis history page
- [ ] PDF report export
- [ ] Comparison view (multiple URLs)
- [ ] Subscription management
- [ ] Dark/light theme toggle
- [ ] Internationalization

## Contributing

This is a proprietary project for Thatworkx Solutions.

## Support

For issues or questions:
- Email: support@thatworkx.com
- GitHub: jessgeo-personal/tw-aeo-suite-v2

## License

Proprietary - Thatworkx Solutions © 2026
